var app = require("express")();
var http = require("http").createServer(app);
var io = require("socket.io")(http);

var SerialPort = require('serialport');
const parsers = SerialPort.parsers;

const parser = new parsers.Readline({
    // delimiter: '\r\n'
    delimiter: '\n'
});

var port = new SerialPort('/dev/tty.usbmodem14201',{ 
  baudRate: 9600,
  dataBits: 8,
  parity: 'none',
  stopBits: 1,
  flowControl: false
});

port.pipe(parser);

io.on("connection", (socket) => {
  console.log("App is connected!");

  socket.on("brightness", function (data) {
    port.write( data.status);
    console.log("Brightness", data);
  });

  socket.on("color", function (data) {
    port.write( data.status );
    console.log("Color", data);
  });

  socket.on("pattern", function (data) {
    port.write( data.status );
    console.log("Pattern", data);
  });

  socket.on("ledOn", function (data) {
    port.write( data.status );
    console.log("Here is data from the app", data);
  });
});

http.listen(3000, () => {
  console.log("listening on localhost:3000");
});
